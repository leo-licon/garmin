from datetime import datetime
from . import db


class BodyMetric(db.Model):
    """Daily body composition entry (Phase 1)"""
    __tablename__ = 'body_metrics'

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True)
    weight_kg = db.Column(db.Float, nullable=False)
    muscle_mass_kg = db.Column(db.Float)
    body_fat_pct = db.Column(db.Float)
    bone_mass_kg = db.Column(db.Float)
    water_pct = db.Column(db.Float)
    bmi = db.Column(db.Float)
    visceral_fat = db.Column(db.Integer)
    fit_file_path = db.Column(db.String(512))
    garmin_upload_status = db.Column(db.String(32), default='pending')  # pending|success|error
    garmin_upload_at = db.Column(db.DateTime)
    garmin_error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat(),
            'weight_kg': self.weight_kg,
            'muscle_mass_kg': self.muscle_mass_kg,
            'body_fat_pct': self.body_fat_pct,
            'bone_mass_kg': self.bone_mass_kg,
            'water_pct': self.water_pct,
            'bmi': self.bmi,
            'visceral_fat': self.visceral_fat,
            'garmin_upload_status': self.garmin_upload_status,
            'garmin_upload_at': self.garmin_upload_at.isoformat() if self.garmin_upload_at else None,
        }


class WorkoutPlan(db.Model):
    """Weekly workout plan uploaded as JSON (Phase 2)"""
    __tablename__ = 'workout_plans'

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(256), nullable=False)
    source = db.Column(db.String(32), default='upload')  # upload | watched_dir
    raw_json = db.Column(db.Text, nullable=False)
    total_workouts = db.Column(db.Integer, default=0)
    processed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    workouts = db.relationship('Workout', backref='plan', lazy=True, cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'filename': self.filename,
            'source': self.source,
            'total_workouts': self.total_workouts,
            'workouts': [w.to_dict() for w in self.workouts],
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'created_at': self.created_at.isoformat(),
        }


class Workout(db.Model):
    """Individual workout from a plan (Phase 2)"""
    __tablename__ = 'workouts'

    id = db.Column(db.Integer, primary_key=True)
    plan_id = db.Column(db.Integer, db.ForeignKey('workout_plans.id'), nullable=False)
    name = db.Column(db.String(256), nullable=False)
    sport_type = db.Column(db.String(64), default='running')  # running|cycling|strength|etc.
    scheduled_date = db.Column(db.Date, nullable=False)
    duration_secs = db.Column(db.Integer)
    description = db.Column(db.Text)
    raw_steps = db.Column(db.Text)  # JSON of steps
    fit_file_path = db.Column(db.String(512))
    garmin_workout_id = db.Column(db.String(128))  # ID returned by Garmin after upload
    garmin_upload_status = db.Column(db.String(32), default='pending')  # pending|uploaded|scheduled|error
    garmin_scheduled_at = db.Column(db.DateTime)
    garmin_error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'plan_id': self.plan_id,
            'name': self.name,
            'sport_type': self.sport_type,
            'scheduled_date': self.scheduled_date.isoformat(),
            'duration_secs': self.duration_secs,
            'description': self.description,
            'garmin_workout_id': self.garmin_workout_id,
            'garmin_upload_status': self.garmin_upload_status,
            'garmin_scheduled_at': self.garmin_scheduled_at.isoformat() if self.garmin_scheduled_at else None,
            'garmin_error': self.garmin_error,
        }


class GarminSession(db.Model):
    """Stores Garmin OAuth tokens"""
    __tablename__ = 'garmin_session'

    id = db.Column(db.Integer, primary_key=True, default=1)
    token_dir = db.Column(db.String(512), default='/data/garmin_tokens')
    is_authenticated = db.Column(db.Boolean, default=False)
    authenticated_at = db.Column(db.DateTime)
    last_used_at = db.Column(db.DateTime)
    username = db.Column(db.String(256))
