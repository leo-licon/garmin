"""
fit_generator.py
────────────────
Generates .fit files from body composition data using the Garmin FIT SDK.

Install: pip install garmin-fit-sdk
"""

import os
import struct
from datetime import datetime, timezone, date
from pathlib import Path
from typing import Optional

# ── Try to import the official Garmin FIT SDK (pip install garmin-fit-sdk) ──
try:
    from fit_tool.fit_file_builder import FitFileBuilder
    from fit_tool.profile.messages.file_id_message import FileIdMessage
    from fit_tool.profile.messages.weight_scale_message import WeightScaleMessage
    from fit_tool.profile.profile_type import Manufacturer, GarminProduct, FileType
    HAS_FIT_SDK = True
except ImportError:
    HAS_FIT_SDK = False


OUTPUT_DIR = os.environ.get('FIT_OUTPUT_FOLDER', '/data/fit_files/body')


def generate_body_composition_fit(
    weight_kg: float,
    measured_date: date,
    muscle_mass_kg: Optional[float] = None,
    body_fat_pct: Optional[float] = None,
    bone_mass_kg: Optional[float] = None,
    water_pct: Optional[float] = None,
    bmi: Optional[float] = None,
    output_dir: Optional[str] = None,
) -> str:
    """
    Generate a Garmin .fit file for body composition data.
    Returns the path to the generated file.
    """
    if not HAS_FIT_SDK:
        raise ImportError(
            "garmin-fit-sdk not installed. Run: pip install garmin-fit-sdk"
        )

    out_dir = Path(output_dir or OUTPUT_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    filename = f"body_{measured_date.isoformat()}.fit"
    filepath = out_dir / filename

    dt = datetime.combine(measured_date, datetime.min.time()).replace(tzinfo=timezone.utc)

    builder = FitFileBuilder(auto_define=True, min_string_size=50)

    # File ID
    file_id = FileIdMessage()
    file_id.type = FileType.WEIGHT
    file_id.manufacturer = Manufacturer.DEVELOPMENT.value
    file_id.product = GarminProduct.FENIX_7.value
    file_id.time_created = round(dt.timestamp() * 1000)
    file_id.serial_number = 0x12345678
    builder.add(file_id)

    # Weight scale message
    ws = WeightScaleMessage()
    ws.timestamp = round(dt.timestamp() * 1000)
    ws.weight = weight_kg * 100  # SDK uses 0.01 kg units → multiply by 100

    if bmi is not None:
        ws.bmi = round(bmi * 10)              # 0.1 units
    if body_fat_pct is not None:
        ws.percent_fat = round(body_fat_pct * 100)  # 0.01% units
    if water_pct is not None:
        ws.percent_hydration = round(water_pct * 100)
    if bone_mass_kg is not None:
        ws.bone_mass = round(bone_mass_kg * 1000)   # grams
    if muscle_mass_kg is not None:
        ws.muscle_mass = round(muscle_mass_kg * 100)  # 0.01 kg units

    builder.add(ws)

    fit_file = builder.build()
    fit_file.to_file(str(filepath))

    return str(filepath)


# ──────────────────────────────────────────────
# If the official SDK is not available, fall back
# to your existing custom script (adapt path here)
# ──────────────────────────────────────────────

def generate_body_composition_fit_legacy(
    weight_kg: float,
    measured_date: date,
    output_dir: Optional[str] = None,
    **kwargs,
) -> str:
    """
    Fallback: calls your existing Python script via subprocess.
    Adapt LEGACY_SCRIPT_PATH to point to your current script.
    """
    import subprocess
    import tempfile
    import json

    LEGACY_SCRIPT_PATH = os.environ.get('LEGACY_FIT_SCRIPT', '/app/legacy/generate_fit.py')

    payload = {"date": measured_date.isoformat(), "weight_kg": weight_kg, **kwargs}
    out_dir = output_dir or OUTPUT_DIR
    Path(out_dir).mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(payload, f)
        tmp_path = f.name

    output_path = str(Path(out_dir) / f"body_{measured_date.isoformat()}.fit")
    result = subprocess.run(
        ['python3', LEGACY_SCRIPT_PATH, tmp_path, output_path],
        capture_output=True, text=True,
    )
    os.unlink(tmp_path)

    if result.returncode != 0:
        raise RuntimeError(f"Legacy FIT script failed: {result.stderr}")

    return output_path
